function [y_fit,res] = fit(x,y)

eps = x;
ita = log(y);
p = polyfit(eps,ita,1);
alpha = exp(p(2));
beta = b;
y_fit = alpha.*exp(beta.*x);

res = abs(y-y_fit);


