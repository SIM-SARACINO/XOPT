function [x,fbest,stats,nfit,fgen,lgen,lfit] = XOPT	% alternative call for save data and further analysis
%function [x,fbest,stats,nfit,fgen,lgen,lfit,options] = XOPT	% uncomment row number 187 and comment 189 one
% Time test available but not in default mode.  
clc															
clear all
close all

disp("***************************")
disp("           XOPT            ")
disp("      v.1.2014.Octave ")
disp(" Airfoil Optimization Tool ")
disp("***************************")

disp("")

disp("UNIVERSITY of ROMA TRE")
disp("Department of Mechanical and Industrial Engineering")
disp("")
disp(["Supervisors :","\n", "Umberto Iemma.  Associate Professor", "\n", "Lorenzo Burghignoli.  Researcher",\
"\n", "Francesco Centracchio.  PhD Student"]) 
disp("")
disp("Author:\tSimone Saracino" ) 

disp("")

%% Defining global variables
%---------------------------
global N
global nu
global nl

global Re
global Ma
global Alpha
global max_iter_xfoil
global cpmin


%% Extending Path
%----------------
addpath(genpath(pwd));


%% Initializing  No. of panel nodes
% N_max = 330 (XFoil constraint)
% default N = 160
%----------------------------------
N = 160

disp("")

%% Initializing Airfoil-coordinate Matrices
% u	: upper surface 
% l	: lower surface 
% Pu = [xu_1 , zu_1 ; xu_2 , zu_2 ; ......; xu_n , zu_n]	(n x 2 matrix)
% Pl = [xl_1 , zl_1 ; xl2 , zl_2 ; ......; xl_m , zl_m] 	(m x 2 ...)
% Remark
% -	n and m can be equal ( we suggest 'n' to be equal to 'm') ;
% -	the number of point is not a constraint (A 2-3-point selection is reasonable for both 
%	upper and lower surfaces) ;
% see 'http://brendakulfan.com/docs/CST5.pdf' for more detailed information on 'CST' 
% parametric model.
% you may look at ' http://aerospace.illinois.edu/m-selig/ads/coord_database.html ' 
% for a rich airfoil-coordinate database.  
%----------------------------------------------------------------------------------------------
Pu = [ 0.20,0.15 ; 0.50,0.10; 0.70,0.05 ]
Pl = [ 0.20,-0.10 ; 0.50,-0.08; 0.70,-0.02 ]


%% Evaluating  No. upper/lower points 
%------------------------------------
nu = size(Pu,1);
nl = size(Pl,1);


%% chord
% default value c = 1
%--------------------
c = 1

disp("")

%% Airfoil configuration parameters
% X0 = [ Ru,Rl,bu,bl,Pu,Pl,dzu,dzl ]
% Ru, Rl	: leading edge radius of curvature
% bu, bl	: boat-tail angle (radians)
% Pu, Pl	: airfoil-point-coordinate matrix
%dzu,dzl	: closure thickness
%--------------------------------------------------
X0 = [ 0.10,0.10,pi/10,pi/12,Pu(:,1)',Pu(:,2)',Pl(:,1)',Pl(:,2)',0.005,-0.005 ]


%% Evaluating parameters with respect chord length  ( iff c > 1 )
%----------------------------------------------------------------
if ~(c == 1)
	X0_n = [ X0(1:2)./c,X0(3:4),X0(5:end)./c ]
	X0 = X0_n;
endif

disp("")


%% Initializing Reynolds number
% Evaluating Re*c 
%------------------------------
Re = 2E06
if ~(c == 1)
	Rec = Re*c
	Re = Rec;
endif

%% Initializing Mach number
%--------------------------
Ma = 0.5 


%% Initializing attachment angle
% max_iter_xfoil  : maximum iteration as input of XFoil-Newton-solver 
% cpmin 			: resize minimum value of cp axis  to represent airfoil cp distribution
% Remark
% -	you should use small angles and small cpmin values ;
% -	you may also modify the default configuration of XFOIL creating a file '.def' like those contained in
% 	'~/.../XOPT/def/', then you make XFOIL read 'nomeFile.def' moving it in '~/.../XOPT/' 
%	see also 'Run.m' and 'XFoil.m' in '~/.../XOPT/SourceCode' ;
% see XFoil documents section  at  'http://web.mit.edu/drela/Public/web/xfoil/' for more detailed informations
%-------------------------------------------------------------------------------------------------------------
Alpha = 1
max_iter_xfoil = 50
cpmin = -15.0

disp("")


%% Genetic Algorithm configuration variable
% N_pop : number of chromosomes ( choose a number of airfoils generated in each generation);
% P_cross : cross-over probability (default value = 0.5) ;
% P_mut : mutation probability	(default value = 0.01) ;
% Maxgen : maximum number of generations ( gen_0, gen_1, ..., Maxgen ) ;
% elite : No. of best individuals exported in new generations from the older ones ; 
% The option list below is not complete so we suggest you to see 'goptions.m'  and  'genetic.m'  
% in  '~/.../XOPT/SourceCode' for more detailed informations.
%----------------------------------------------------------------------------------------------
N_pop = 30
P_cross = 0.5
P_mut = 0.01
Maxgen = 30
elite = 0


%% Initializing upper and lower bounds
% UB-u 	: upper bound-upper surface point matrix
% UB_l	: upper bound-lower...
% UB	: upper bound string (all parameters)
%
% LB_u  : lower bound-upper surface point matrix
% LB_l  : lower bound-lower...
% LB    : lower bound string (all parameters)	
%------------------------------------------------
UB_u = [ 0.25,0.15 ; 0.55,0.15 ; 0.75,0.10 ];
LB_u = [ 0.15,0.05 ; 0.45,0.05 ; 0.65,0.02 ];

UB_l = [ 0.25,-0.05 ; 0.55,-0.04 ; 0.75,-0.01 ];
LB_l = [ 0.15,-0.10 ; 0.45,-0.08 ; 0.65,-0.02 ];

UB = [ 0.10,0.10,pi/8,pi/10,UB_u(:,1)',UB_u(:,2)',UB_l(:,1)',UB_l(:,2)',0.005,-0.004 ]
LB = [ 0.06,0.06,pi/12,-pi/10,LB_u(:,1)',LB_u(:,2)',LB_l(:,1)',...
							LB_l(:,2)',0.004,-0.005 ]


%% Initializing bit number for each configuration variable
% bits_u	:  upper-point-coordinate bit matrix
% bits_l	:  lower...
% bits		:  bit string (all parameters)
% Remark	:
% the space dimension  of i-th variable is 2^i order 
%----------------------------------------------------------
bits_u = [ 8,8 ; 8,8 ; 8,8 ];
bits_l = [ 8,8 ; 8,8 ; 8,8 ];

bits = [ 6,6,4,4,bits_u(:,1)',bits_u(:,2)',bits_l(:,1)',bits_l(:,2)',4,4 ]


%% Generating Data Folders
%-------------------------
mkdir("run");
mkdir("pol");
mkdir("Cp");
%mkdir("log");
mkdir("foil");
mkdir("gen");


%t0=cputime %Time test

%% Genetic Subroutine
% Remark
% The calling at 'goptions.m'  has been integrated  in 'genetic.m' but maybe you modify 
% the default variables here : you should uncomment line the first line of this command section
% and comment the next one.
% The default stop-criterion is 'bit string affinity value' (BSA) : the default value is 0.9 (2°position
% in options);
% see 'goptions.m' and 'genetic.m' in 'XOPT/SourceCode'  for more detailed informations
%--------------------------------------------------------------------------------------------------------

%options = goptions([1,0.9,0,0,elite,0,0,0,0,0,N_pop,P_cross,P_mut,Maxgen]);

options=[1,0.9,0,0,elite,0,0,0,0,0,N_pop,P_cross,P_mut,Maxgen];
[x,fbest,stats,nfit,fgen,lgen,lfit] = genetic(@Run,X0,options,LB,UB,bits);

%t1=cputime

%% Display result and statistics
% Remark
% It may be possible that a recent version of  Octave display this warning :
% "warning: '...' continuations in double-quoted character strings are obsolete 
% and will not be allowed in a future version of Octave; please use '\' instead ";
% Correction in not complete !
%---------------------------------------------------------------------------------
disp(["xopt= ",num2str(x),"\n","fbest= ",num2str(fbest),"\n","nfit= ",\
      num2str(nfit)])
disp("fgen= "),disp(fgen)
disp("lgen= "),disp(lgen)
disp("lfit= "),disp(lfit)
disp("")
%printf("Time_Opt(s)= %.3f\n",t1-t0)

% end XOPT

%% Upgrade
%---------
% 1) Convergence analysis
% 2) Interpolation Subroutine of an existing airfoil
% 3) Visualisation improvement 
% 4) A.M.V. : Airfoil Morphing Visualisation

%% Next Version Features
% Program
%-----------------------
% 1) new genetic operators
% 2) hybrid implementation
% 3) wing analysis
%(4) I.G.A. : Intelligent Genetic Algorithm. see handbook.txt form further informations.

