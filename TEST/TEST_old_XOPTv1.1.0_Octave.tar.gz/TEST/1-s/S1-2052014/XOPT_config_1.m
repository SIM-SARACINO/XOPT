clc
clear all
close all

disp("***************************")
disp("           XOPT            ")
disp(" Airfoil Optimization Tool ")
disp("***************************")

global N
global Re
global Alpha
global max_iter_xfoil
global cpmin

addpath(genpath(pwd));

N = 160
x0u = [0.20,pi/8,0.25,0.15,0] 
c = 1
if ~(c == 1)
	x0u_n = [x0u(1)/c,x0u(2),x0u(3:5)./c]
	x0u = x0u_n;
endif

Re = 2E06
if ~(c == 1)
	Rec = Re*c
	Re = Rec;
endif

Alpha = 1
max_iter_xfoil = 50
cpmin = -15.0

N_pop = 20
P_cross = 0.5
P_mut = 0.01
Maxgen = 10
elite = 0
LB = [0.10,pi/18,0.15,0.05,0]
UB = [0.20,pi/6,0.30,0.20,0.01]
bits = [10,10,10,10,5]

%% DATA FOLDERs
mkdir("run");
mkdir("pol");
mkdir("Cp");
mkdir("log");
mkdir("foil");
mkdir("gen");

t0=cputime; %Time test

%options = goptions([1,0.9,0,0,elite,0,0,0,0,0,N_pop,P_cross,P_mut,Maxgen]);
options=[1,0.8,0,0,elite,0,0,0,0,0,N_pop,P_cross,P_mut,Maxgen];
[x,fbest,stats,nfit,fgen,lgen,lfit] = genetic(@Run,x0u,options,LB,UB,bits);

t1=cputime;
	
disp(["x0_Opt= ",num2str(x),"\n","fbest= ",num2str(fbest),"\n","nfit= ",...
      num2str(nfit)])
disp("fgen= "),disp(fgen)
disp("lgen= "),disp(lgen)
disp("lfit= "),disp(lfit)
printf("Time_Opt(s)= %.3f\n",t1-t0)



	
