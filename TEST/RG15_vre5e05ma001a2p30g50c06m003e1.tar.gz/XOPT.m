function [x,fbest,stats,nfit,fgen,lgen,lfit,BSA_pop] = XOPT	% alternative call for save data and further analysis
%function [x,fbest,stats,nfit,fgen,lgen,lfit,options] = XOPT	% uncomment row number 187 and comment 189 one
% Time test available but not in default mode.  
clc															
clear all
close all

disp("***************************")
disp("           XOPT            ")
disp("      v.1.2014.Octave ")
disp(" Airfoil Optimization Tool ")
disp("***************************")

disp("")

disp("UNIVERSITY of ROMA TRE")
disp("Department of Mechanical and Industrial Engineering")
disp("")
disp(["Supervisors :","\n", "Umberto Iemma.  Associate Professor", "\n", "Lorenzo Burghignoli.  Researcher",...
"\n", "Francesco Centracchio.  PhD Student"]) 
disp("")
disp("Author:\tSimone Saracino" ) 

disp("")

%% Defining global variables
%---------------------------
global N
global nu
global nl

global Re
global Ma
global Alpha
global max_iter_xfoil
global cpmin


%% Extending Path
%----------------
addpath(genpath(pwd));


%% Initializing  No. of panel nodes
% N_max = 330 (XFoil constraint)
% default N = 160
%----------------------------------
N = 160

disp("")

%% Initializing point-coordinate Matrices
% u	: upper surface 
% l		: lower surface 
% Pu = [xu_1 , zu_1 ; xu_2 , zu_2 ; ......; xu_n , zu_n]	(n x 2 matrix)
% Pl = [xl_1 , zl_1 ; xl2 , zl_2 ; ......; xl_m , zl_m] 		(m x 2 ...)
% n = m, n > m, n < m 
% iff  n = m  then  BPO_u == BPO_l , same order of Bernstein' polynomials for upper/lower
% see 'http://brendakulfan.com/docs/CST5.pdf' for more detailed information on  " CST " 
% parametric model
% you may look at ' http://aerospace.illinois.edu/m-selig/ads/coord_database.html ' 
% for airfoil-coordinate databases.  
%-----------------------------------------------------------------------------------------
Pu = [ 0.00932  0.01214 ; 0.21624  0.05810 ; 0.64723  0.04612 ; 0.95248  0.00865 ]
Pl = [ 0.94748  0.00101 ; 0.66244 -0.01366 ; 0.30221 -0.02762 ; 0.02670 -0.01436 ]


%% Evaluating  No. upper/lower points 
%------------------------------------
nu = size(Pu,1);
nl = size(Pl,1);


%% chord
% default value c = 1
%--------------------
c = 1

disp("")

%% Airfoil configuration parameters
% X0 = [ Ru,Rl,bu,bl,Pu,Pl,dzu,dzl ]
% Ru, Rl	: leading edge radius of curvature
% bu, bl	: boat-tail angle (radians)
% Pu, Pl	: airfoil-point-coordinate matrix
%dzu,dzl	: closure thickness
%--------------------------------------------------
X0 = [0.00495,0.00495,0.089,0.0,Pu(:,1)',Pu(:,2)',Pl(:,1)',Pl(:,2)',0.001,-0.001]


%% Evaluating parameters with respect chord length  ( iff c > 1 )
%----------------------------------------------------------------
if ~(c == 1)
	X0_n = [ X0(1:2)./c,X0(3:4),X0(5:end)./c ]
	X0 = X0_n;
endif

disp("")


%% Initializing Reynolds number
% Evaluating Re*c 
%------------------------------
Re = 0.5E06
if ~(c == 1)
	Rec = Re*c
	Re = Rec;
endif

%% Initializing Mach number
%--------------------------
Ma = 0.01 


%% Initializing attachment angle
% max_iter_xfoil  : maximum iteration as input of XFoil-Newton-solver 
% cpmin 			: resize minimum value of cp axis  to represent airfoil cp distribution
% Advices	:
% you should use small angles and small cpmin values
% you may also modify the default configuration of XFOIL creating a '.def' file like those contained in
% def folder, then you make XFOIL read .def. see  'Run.m' and 'XFoil.m'. 
% see XFoil documents section  at  'http://web.mit.edu/drela/Public/web/xfoil/' for more detailed informations
%-------------------------------------------------------------------------------------------------------------
Alpha = 2
max_iter_xfoil = 30
cpmin = -10.0

disp("")


%% Genetic Algorithm configuration parameters
% N_pop : chromosome number
% P_cross : cross-over probability					(default value = 0.5)
% P_mut : mutation probability						(default value = 0.01)
% Maxgen : maximum number of generations		( gen_0, gen_1, ..., Maxgen )
% elite : No. of best individuals exported in new generations from the older ones 
% see also 'goptions.m'  and  'genetic.m'  in  '~/.../XOPT/SourceCode' 
% for more detailed informations
%----------------------------------------------------------------------------------------------
N_pop = 30
P_cross = 0.5
P_mut = 0.03
Maxgen = 50
elite = 1


%% Initializing upper and lower bounds
% UB-u 	: upper bound-upper surface point matrix
% UB_l	: upper bound-lower...
% UB	:  upper bound string (all parameters)
%
% LB_u  : lower bound-upper surface point matrix
% LB_l  : lower bound-lower...
% LB    : lower bound string (all parameters)	
%--------------------------------------------------------
UB_u = Pu+Pu.*0.1;
LB_u = Pu-Pu.*0.1;

UB_l = Pl+abs(Pl.*0.3);
LB_l = Pl-abs(Pl.*0.3);

UB = [ 0.008,0.008,0.15,0.02,UB_u(:,1)',UB_u(:,2)',UB_l(:,1)',UB_l(:,2)',0.0015,-0.0005 ]
LB = [ 0.004,0.004,0.0,-0.10,LB_u(:,1)',LB_u(:,2)',LB_l(:,1)',LB_l(:,2)',0.0005,-0.0015 ]


%% Initializing bit number for each configuration variable
% bits_u	:  upper point-coordinate bit matrix
% bits_l	:  lower...
% bits		:  bit string (all parameters)
% Remark	:
% the space dimension  of i-th variable is of 2^i order 
%----------------------------------------------------------
bits_u = ones(nu,2).*6;
bits_l = ones(nl,2).*6;

bits = [ 3,3,3,3,bits_u(:,1)',bits_u(:,2)',bits_l(:,1)',bits_l(:,2)',2,2 ]


%% Generating Data Folders
%-------------------------
mkdir("run");
mkdir("pol");
mkdir("Cp");
%mkdir("log");
mkdir("foil");
mkdir("gen");


%t0=cputime %Time test

%% Genetic Subroutine
% Advice	:
% The calling at 'goptions.m'  has been integrated  in 'genetic.m'
% see 'goptions.m' and 'genetic.m' in 'XOPT/SourceCode'  for more detailed informations
%--------------------------------------------------------------------------------------

%options = goptions([1,0.8,0,0,elite,0,0,0,0,0,N_pop,P_cross,P_mut,Maxgen]);

options=[1,0.9,0,0,elite,0,0,0,0,0,N_pop,P_cross,P_mut,Maxgen];

tstart=tic;

[x,fbest,stats,nfit,fgen,lgen,lfit,xopt_out,BSA_out] = genetic(@Run,X0,options,LB,UB,bits);

tcomp=toc(tstart);
 
save -ascii "BSA.out" BSA_out
save -ascii "xopt_iter.out" xopt_out
save -ascii "STATs.out" stats
    
%% Display result and statistics
% Advice	:
% It may be possible that a recent version of  Octave display this warning :
%" warning: '...' continuations in double-quoted character strings are obsolete 
% and will not be allowed in a future version of Octave; please use '\' instead ";
% Correction in not complete !
%---------------------------------------------------------------------------------
disp(["xopt= ",num2str(x),"\n","fbest= ",num2str(fbest),"\n","nfit= ",...
      num2str(nfit)])
disp("fgen= "),disp(fgen)
disp("")
disp("lgen= "),disp(lgen)
disp("")
disp("lfit= "),disp(lfit)
sprintf("\nBSA_last = %3.4f\n",BSA_out(end,2))
sprintf("Time_Opt(s) = %.3f\n",tcomp)

% end XOPT
